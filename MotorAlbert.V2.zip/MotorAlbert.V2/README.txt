# Motor Gráfico - Práctica

## Descripción
Motor gráfico 3D desarrollado en C++ con OpenGL 4.6 y SDL3.
Incluye carga de modelos FBX, texturas, cámara libre tipo editor
y optimización mediante Frustum Culling con Octree.

## Características
- Carga de modelos FBX (Assimp)
- Texturas PNG (stb_image)
- Editor con ImGui (Docking)
- Viewport con Framebuffer
- Cámara FPS
- Selección de objetos por raycast
- Frustum Culling activable
- Octree para aceleración espacial
- Visualización de normales
- Grid de referencia

## Controles
- Click derecho + ratón: mover cámara
- WASD: desplazamiento
- Click izquierdo: seleccionar objeto
- Supr: borrar objeto
- Ctrl + D: duplicar
- H: ocultar objeto
- N: mostrar/ocultar normales

## Librerías usadas
- SDL3
- OpenGL 4.6
- GLAD
- ImGui
- Assimp
- stb_image
- GLM

## Autor
Albert Frederic Bailen Ruesca (Continuo Solo en la entrega)

Link GitHub: https://github.com/Fredi223/MotorAlbert